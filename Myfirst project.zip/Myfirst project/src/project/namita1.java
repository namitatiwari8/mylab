package project;

public class namita1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("Hello world");
		
		int width=8;
		int hight=12;
		int area=96;
		double radius=10.0;
		double pie=3.14;
		boolean result=true;
		System.out.println("The value of width is"+ width);
		System.out.println("The value of hight is"+hight);
		System.out.println("the value of area is"+area);
		System.out.println("the value of radius is"+radius);
		System.out.println("thevalue of pie"+ pie);
		System.out.println("the value of result is"+ result);
		
		int [] daysInMonths= new int[12];
        String[] monthNames =new String[12];
        
        daysInMonths[0]=31;
        daysInMonths[1]=28;
        daysInMonths[2]=31;
        daysInMonths[3]=30;
        daysInMonths[4]=31;
        daysInMonths[5]=30;
        daysInMonths[6]=31;
        daysInMonths[7]=31;
        daysInMonths[8]=30;
        daysInMonths[9]=31;
        daysInMonths[10]=30;
        daysInMonths[11]=31;
        monthNames [0] ="January";
        monthNames [1] ="February";
        monthNames [2] ="March";
        monthNames [3] ="Apil";
        monthNames [4] ="May";
        monthNames [5] ="June";
        monthNames [6] ="July";
        monthNames [7] ="August";
        monthNames [8] ="September";
        monthNames [9] ="October";
        monthNames [10] ="November";
        monthNames [11] ="December";
       System.out.println(monthNames [0]+  "has"+ " "+daysInMonths[0]+ "days");
        		
       System.out.println(monthNames [1]+  "has"+ " "+daysInMonths[1]+ "days");
       System.out.println(monthNames [2]+  "has"+ " "+daysInMonths[2]+ "days");
       System.out.println(monthNames [3]+  "has"+ " "+daysInMonths[3]+ "days");
       System.out.println(monthNames [4]+  "has"+ " "+daysInMonths[4]+ "days");
       System.out.println(monthNames [5]+  "has"+ " "+daysInMonths [5]+ "days");
       System.out.println(monthNames [6]+  "has"+ " "+daysInMonths[6]+ "days");
       System.out.println(monthNames [7]+  "has"+ " "+daysInMonths[7]+ "days");
       System.out.println(monthNames [8]+  "has"+ " "+daysInMonths[8]+ "days");
       System.out.println(monthNames [9]+  "has"+ " "+daysInMonths[9]+ "days");
       System.out.println(monthNames [10]+  "has"+ " "+daysInMonths[10]+ "days");
       System.out.println(monthNames [11]+  "has"+ " "+daysInMonths[11]+ "days");
		
	}	
		
		
}
