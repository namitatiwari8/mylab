/**
*
*/package com.lq.test;

importjava.util.scanner;

/**
 * @author mehrt
 * 
 */

int x=30;
int y;
Scanner scn=new Scanner(system.in);
y=scn.nextInt();
if(x<y) {
	system.out.println("xis g");}
	else {
		system.out.println("xis  less");
}
}
