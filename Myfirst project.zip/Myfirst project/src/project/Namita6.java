

package project;

public class Namita6 {

	public static void main(String[] args) {

	// TODO Auto-generated method stub
	int i = 0;
	do {
	System.out.println("*");}
	
	while (i>0);
	}
	
	
	
	
	
	
	
	
	//
    int[ ]numbers = {5,19,23};
        		
    }
	
	

