package project;

public class Lab3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
 int i=1;
 int j=1;
 
 while(i<=20) {
	  
				
		if(i%2==0)
		System.out.println(i);
		
		i=i+1;
	
		
		
		
		
	}
 
 

		 for(j=1;j<=100;j++) {
			 
			 

		 if (j>=50 && j<=60)

		   continue;
			 System.out.println(j);
		 

		 }
		 

}
}
