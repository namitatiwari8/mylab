package project;

public class Namita4 {

	public static void main(String[] args) {
	// TODO Auto-generated method 
		
		int time = 10;

		if (time < 10) {

		  System.out.println("Good morning.");

		} else if (time < 20) {

		  System.out.println("Good day.");

		} else {

		  System.out.println("Good evening.");

		}
	
		
}
}