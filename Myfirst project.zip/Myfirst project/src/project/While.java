package project;

import java.util.Scanner;

public class While {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner scn=new Scanner(System.in);
int i=scn.nextInt();
int n=20;
while(i<n) {
	System.out.println("*");
	i++;
}
		
		
		
		
	}

}
