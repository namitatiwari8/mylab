
package comjavaoo.store;

import javax.swing.Spring;

public class Artist {
private String name;
String [] memberNames =new String[20];
String[] memberinstruments =new String[20];
	/**
 * @return the name
 */
public final String getName() {
	return name;
}
/**
 * @param name the name to set
 */
public final void setName(String name) {
	this.name = name;
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
