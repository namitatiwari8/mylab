package comjavaoo.store;

public class Item {

	/**
	 * @return the title
	 */
	public final String getTitle() {
		return title;
	}

	/**
	 * @param title the title to set
	 */
	public final void setTitle(String title) {
		this.title = title;
	}

	/**
	 * @return the price
	 */
	public final double getPrice() {
		return price;
	}

	/**
	 * @param price the price to set
	 */
	public final void setPrice(double price) {
		this.price = price;
	}

	/**
	 * @return the quantity
	 */
	public final int getQuantity() {
		return quantity;
	}

	/**
	 * @param quantity the quantity to set
	 */
	public final void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	private String title;
	private double price;
	private int quantity;
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
