package comjavaoo.store;

public class Book extends Item {
private String Author;
private String publisher;
private String category;
	/**
 * @return the author
 */
public final String getAuthor() {
	return Author;
}
/**
 * @param author the author to set
 */
public final void setAuthor(String author) {
	Author = author;
}
/**
 * @return the publisher
 */
public final String getPublisher() {
	return publisher;
}
/**
 * @param publisher the publisher to set
 */
public final void setPublisher(String publisher) {
	this.publisher = publisher;
}
/**
 * @return the category
 */
public final String getCategory() {
	return category;
}
/**
 * @param category the category to set
 */
public final void setCategory(String category) {
	this.category = category;
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
