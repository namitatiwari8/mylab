package ooconceps;

public interface Icar {

}
