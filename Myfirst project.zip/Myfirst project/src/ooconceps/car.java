package ooconceps;

public class car {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
