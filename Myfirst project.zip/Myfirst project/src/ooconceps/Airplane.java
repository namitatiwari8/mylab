package ooconceps;

public class Airplane {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
