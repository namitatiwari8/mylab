package iqvehicle;

public abstract class Car {
  protected int speed;
  
  private boolean enginestate;
  public abstract void setspeed(int speed);
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
